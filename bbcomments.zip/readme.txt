=== Plugin Name ===
Contributors: mario priebe
Donate link: http://www.biggle.de
Tags: comments, bbcode
Requires at least: 2.0.2
Tested up to: 0.3
Stable tag: 0.3

use simple bbcode in your comments

== Description ==

use simple BBCode in your comments
atm follow tags available:

[b]bold[/b]
[i]italic[/i]
[u]underline[/u]
[color=color]text[/color] example [color=FF6600]Text[/color]

list
[ul]
[li]number 1[/li]
[li]number 2[/li]
[li]number 3[/li]
[/ul]

[url=http://www.google.com]Google[/url]
[img=http://uri.to.pic][/img] (fix picsize)


(required wp-syntax)
[code]your code[/code],  
optional with declaration of the language
[code lang="csharp"]your sample code[/code] (all available languages from wp-syntax possible)


== Installation ==

1. Upload `BBComment` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. done

== Frequently Asked Questions ==

= u need more tags? =

visit the author website


== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot


== Arbitrary section ==

Visit my blog for more nice wordpress plugins and .net tutorials and codes : )


